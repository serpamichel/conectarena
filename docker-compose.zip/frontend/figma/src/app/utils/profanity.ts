const PROFANITY_LIST = [
  'merda',
  'porra',
  'caralho',
  'bosta',
  'foda',
  'fodase',
  'bananona',
];

function normalizeText(s: string) {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ');
}

export function findProfanities(text: string): string[] {
  const norm = normalizeText(text || '');
  const found = new Set<string>();
  for (const word of PROFANITY_LIST) {
    const normWord = normalizeText(word).trim();
    if (!normWord) continue;
    const re = new RegExp(`\\b${normWord}\\b`, 'i');
    if (re.test(norm)) found.add(word);
  }
  return Array.from(found);
}

export function containsProfanity(text: string): boolean {
  return findProfanities(text).length > 0;
}

export default containsProfanity;
